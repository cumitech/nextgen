<?php
require('C:/xampp/htdocs/moodle/config.php');
$admin = get_admin();
complete_user_login($admin);
redirect(new moodle_url('/course/view.php', ['id' => 2]));
